<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" type="text/css" href="{{ URL::asset('css/style.css') }}">
    <link rel = "icon" href = "{{ URL::asset('image/icon.png') }}" type = "image/x-icon">
    <title>Checkout - Supermiya Mnemonika Online Treningi</title>
</head>
<body> 
    <section class="hero"> 
        <h1 class="top">8.464.000 SO`M TEJAB QOLISH UCHUN HOZIROQ RO`YXATDAN O`TING</h1>
        
            <h1 class="relative">
                <div class="strike strike1"></div>
                <div class="strike strike2"></div>
                9,655,000 So`m
            </h1>

            <p class="text-price">
                <span class="price">497,000 SO`M</span>
            </p>
            <p>
                <svg width="100px" height="100px" viewBox="0 0 262.000000 268.000000" preserveAspectRatio="xMidYMid meet">
               <g transform="translate(0.000000,268.000000) scale(0.100000,-0.100000)" fill="#E73A04" stroke="none">
               <path d="M1210 2611 c-57 -9 -85 -24 -108 -58 -16 -25 -17 -90 -22 -893 l-5
               -865 -165 170 c-189 195 -355 368 -455 472 -82 87 -134 112 -194 95 -54 -17
               -207 -176 -216 -226 -18 -91 -39 -65 563 -670 306 -307 579 -576 605 -597 42
               -33 56 -39 97 -39 41 0 55 6 97 39 26 21 298 290 604 597 597 599 579 577 564
               666 -6 34 -22 57 -93 130 -101 105 -136 121 -205 94 -29 -11 -67 -40 -112 -89
               -100 -104 -266 -277 -455 -472 l-165 -170 -5 865 c-5 805 -6 868 -23 893 -9
               15 -30 33 -46 42 -34 17 -194 27 -261 16z"></path>
               </g>
               </svg>
            </p>

            <div class="white">
                <p class="sub-text text-bold">1. Ro`yxatdan o`tish uchun quyidagi kartalardan biriga to`lovni amalga oshirasiz:</p>
                <p class="sub-text text-bold">▫️ UZCARD: 497,000 So`m<br>
                    8600-1404-7171-4759<br>
                    TURDIYEV DOVRANBEK
                </p>
                <p class="sub-text  text-bold">▫️ VISA: $49<br>
                    4231-2000-0099-4276<br>
                    KHAYOT SHARAPOV
                </p>
                <p class="sub-text text-bold">2. To`lovingiz muvaffaqiyatli amalga oshganini tasdiqlovchi rasmni telefoningizda saqlab qolasiz.</p>
                <p class="sub-text text-bold">3. Va quyidagi anketani to`ldirasiz.</p>
            </div>

            <form action="{{route('checkout')}}" class="registration" enctype="multipart/form-data" method="POST">
                <label for="name">Ism-familiyangiz <span class="symbol">*</span></label>
                <input type="text" name="name" id="name" placeholder="Dovranbek Turdiev" value="{{$name?$name:""}}">
                @csrf
                <label for="phone">Telefon raqamingiz <span class="symbol">*</span></label>
                <input type="text" name="phone" id="phone" pattern="[0-9()#&+*-=.]+" placeholder="+998 99 1234567" value="{{$phone?$phone:""}}">
                
                <label for="referal">Sizni Supermiyaga kim taklif qildi?</label>
                <input type="text" name="referral" id="referral" placeholder="">
                
                {{-- <label for="invoice">To'lov qilish</label> --}}
                <input type="hidden" id="redirectUrl" value="{{route('checkout')}}"/>
                <input type="hidden" id="course" value="{{$course}}"/>
                
                
                {{-- <iframe id="invoice" style="width: 100%; height:700px;" src="https://oplata.kapitalbank.uz?cash=e46c15bde03346a3ba14dbb6f47f7423&description=Supermiya%20kursi&amount=100000&redirectUrl=google.com"></iframe> --}}
                
                {{-- <input id="verify" type="button" value="Verify"> --}}
                <label for="amount">Narx:</label>
                <input type="text" id="amount" value="100000" disabled>
                <p class="center"><a style="color: red; text-align:center;" href="" id="link">Pay</a><br></p>

                

                {{-- <label for="invoice">To`lovingiz chekini kiriting <span class="symbol">*</span></label>
                <input type="file" name="invoice" id="invoice"> --}}

                <input type="hidden" name="leed_id" id="leed_id" value="{{$leed_id?$leed_id:"null"}}">
                <input type="hidden" name="course_id" id="course_id" value="1">
                
                <input type="submit" value="RO'YXATDAN O'TISH">
                <p class="sub-text white text-bold"><span class="symbol text-bold">*</span>Ro`yxatdan o`tish tugmachasini bosganingizdan so`ng keyingi sahifasiga yo`naltirilasiz. Bu internetingiz tezligiga qarab ba`zida 30 soniyagacha borishi mumkin.</p>
                
            </form>
                
                
                <div id="popup"><iframe id="popupiframe"></iframe></div>
                <div id="popupdarkbg"></div>


            <script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/3.1.9-1/crypto-js.js"></script>
            <script>

                // var verify = document.getElementById('verify');
                // var iframe = document.getElementById("invoice");
                // verify.addEventListener("click", function() {
                //     console.log(iframe.contentWindow.document.getElementsByClassName('description')[0].innerHTML);
                //     if(iframe.contentWindow.document.querySelector('.info_').children[2]){
                        
                //     }else{console.log("false");}
                // });
                
                // document.querySelector('.confirm-box').children[2].children[0].onclick = function hello() {
                //     alert('Hello');
                // };
                
                var phone = document.getElementsByName("phone").value;
                
                var leed_id = document.getElementById('leed_id').value;
                var course_id = document.getElementById('course_id').value;
                
                var redirectUrl = document.getElementById('redirectUrl').value;
                
                var course = document.getElementById('course').value;
                var amount = document.getElementById('amount').value;
                
                var encrypted;
//U2FsdGVkX18ZUVvShFSES21qHsQEqZXMxQ9zgHy+bu0=

                document.getElementById("link").onclick = function(e) {
                        e.preventDefault();
                        name = document.getElementById("name").value;
                        // console.log(name);
                        phone = document.getElementById("phone").value;
                        referral = document.getElementById('referral').value?document.getElementById('referral').value:"null";
                        encrypted = CryptoJS.MD5(amount);
                        // redirectUrl = redirectUrl+"/"+course+"/"+name+"/"+phone+"/"+encrypted;
                        // redirectUrl = redirectUrl;
                        console.log(redirectUrl);
                        // console.log(phone);
                        document.getElementById("popupdarkbg").style.display = "block";
                        document.getElementById("popup").style.display = "block";
                        if(!document.getElementById('popupiframe').src){
                            document.getElementById('popupiframe').src="https://oplata.kapitalbank.uz?cash=e46c15bde03346a3ba14dbb6f47f7423&description=Supermiya%20kursi&amount="+amount+"&redirectUrl="+redirectUrl+"&name="+name+"&phone="+phone+"&referral="+referral+"&leed_id="+leed_id+"&course_id="+course_id+"&URL=supermozg.uz/checkout";
                        }
                        document.getElementById('popupdarkbg').onclick = function() {
                            document.getElementById("popup").style.display = "none";
                            document.getElementById("popupdarkbg").style.display = "none";
                        };
                    return false;
                }   

                window.onkeydown = function(e) {
                    if (e.keyCode == 27) {
                    document.getElementById("popup").style.display = "none";
                    document.getElementById("popupdarkbg").style.display = "none";
                    e.preventDefault();
                    return;
                    }
                }
            </script>
            <style>
                #popup { display: none; position: fixed; top: 12%; 
                    right:50%; 
    margin-right:-250px; 
    width:500px;
                    height: 75%; background-color: white; z-index: 10; }
                #popup iframe { width: 500px; margin: 0px auto; height: 100%; border: 0; }
                #popupdarkbg { position: fixed; z-index: 5; left: 0; top: 0; width: 100%; height: 100%; overflow: hidden; background-color: rgba(0,0,0,.75); display: none; }
            </style>
    </section>
    @include('partials.footer')
</body>
<script>

// document.getElementsByClassName('success_')[0].innerHTML //Платеж успешно проведен
// document.getElementsByClassName('description')[0].innerHTML//Supermiya kursi

// document.getElementsByClassName('details-child-text')[0].innerHTML //Пункт обслуживания
// document.getElementsByClassName('details-child-text')[1].innerHTML //90490021563

// document.getElementsByClassName('details-child-text')[2].innerHTML //Терминал
// document.getElementsByClassName('details-child-text')[3].innerHTML //91103270

// document.getElementsByClassName('details-child-text')[4].innerHTML //Номер транзакции
// document.getElementsByClassName('details-child-text')[5].innerHTML //012191173205

// document.getElementsByClassName('details-child-text')[6].innerHTML //Время оплаты
// document.getElementsByClassName('details-child-text')[7].innerHTML //27.08.2021 16:36:38

// document.getElementsByClassName('details-child-text')[8].innerHTML //Карта
// document.getElementsByClassName('details-child-text')[9].innerHTML //8600 49** **** 1923

// document.getElementsByClassName('details-child-text')[10].innerHTML //Сумма платежа
// document.getElementsByClassName('details-child-text')[11].innerHTML //1,000.00 сум



</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="{{ URL::asset('js/app.js') }}"></script>
</html>