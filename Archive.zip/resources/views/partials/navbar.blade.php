<div class="menu">
	<div class="heading">
		<p>{{Auth::user()->role}} panel</p>
		<div class="menu-icon js-toggle-menu">
			<span></span>
			<span></span>
			<span></span>
		</div>
	</div>
	<div class="wrap">
		@if(Auth::user()->isAdmin())
			<a href="{{route('admin.dashboard')}}">Dashboard</a>
		@else
			<a href="{{route('user.dashboard')}}">Dashboard</a>
		@endif
			<a href="{{route('user.edit')}}">Account</a>

		<p class="title"></p>
		@if(Auth::user()->isAdmin())
			<a href="{{route('admin.leed.index')}}">Leeds</a>

			<p class="title"></p>
			<div class="dropdown">
				<p>Users</p>
				<div class="links">
					<a href="{{route('admin.user.index')}}">All Users</a>
					<a href="{{route('admin.user.create')}}">Create User</a>
				</div>
			</div>
			<div class="dropdown">
				<p>Courses</p>
				<div class="links">
					<a href="{{route('admin.course.index')}}">All Courses</a>
					<a href="{{route('admin.course.create')}}">Create Course</a>
				</div>
			</div>
			<div class="dropdown">
				<p>Videos</p>
				<div class="links">
					<a href="{{route('admin.video.index')}}">All Videos</a>
					<a href="{{route('admin.video.create')}}">Create Video</a>
				</div>
			</div>
			<div class="dropdown">
				<p>Sms</p>
				<div class="links">
					<a href="{{route('admin.sms.index')}}">All Sms</a>
					<a href="{{route('admin.sms.create')}}">Send Sms</a>
				</div>
			</div>
		@else
			<a href="{{route('user.course')}}">Courses</a>
		@endif
		{{-- <div class="dropdown">
			<p>Dropdown</p>
			<div class="links">
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
				<a href="">Dropdown Item</a>
			</div>
		</div> --}}

		{{-- <a href="">Dashboard</a>

		<div class="dropdown">
			<p>Dropdown</p>
			<div class="links">
				<a href="">Dashboard</a>
				<a href="">Dashboard</a>
			</div>
		</div>

		<p class="title">Legal Section</p>

		<div class="dropdown">
			<p>Documents</p>
			<div class="links">
				<a href="">Contract</a>
				<a href="">Employee Handbook</a>
			</div>
		</div>
		<a href="">Terms &amp; Conditions</a>
		<a href="">Copyright Details</a> --}}
	</div>
</div>