@extends('layouts.master')

@section('content')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">

<style>
.flex-container{
    display: flex;
    justify-content: space-around;
    flex-wrap: wrap;
    width: 100%;
    /* margin:0px 10px; */
    /* border: 1px solid blue; */
}

.flex-child{
    width: 400px;
    /* border: 1px solid red; */
    text-align: center;
    height: 100%;
}
img{
    /* border:1px solid green; */
}

video{
    max-width: 400px;
    width: 100%;
}



 input#search-bar {
	 margin: 0 auto;
	 width: 100%;
	 height: 45px;
	 padding: 0 20px;
	 font-size: 1rem;
	 border: 1px solid #d0cfce;
	 outline: none;
}
 input#search-bar:focus {
	 border: 1px solid #008abf;
	 transition: 0.35s ease;
	 color: #008abf;
}
 input#search-bar:focus::-webkit-input-placeholder {
	 transition: opacity 0.45s ease;
	 opacity: 0;
}
 input#search-bar:focus::-moz-placeholder {
	 transition: opacity 0.45s ease;
	 opacity: 0;
}
 input#search-bar:focus:-ms-placeholder {
	 transition: opacity 0.45s ease;
	 opacity: 0;
}
 .search-icon {
	 position: relative;
	 float: right;
	 width: 75px;
	 height: 75px;
	 top: -60px;
	 right: -10px;
}
 

</style>

<div class="container">
    @include('partials.alerts')
    <h1>Videos <span style="float: right"><a class="btn btn-success" href="{{route('admin.video.create')}}">Create</a></span></h1>    
    <p>
        <input type="text" id="search-bar" onkeyup="search()" placeholder="What can I help you with today?">
        <img class="search-icon" src="{{URL::asset('image/search-icon.png')}}">
    </p>     
    <div class="flex-container">
      @foreach($videos as $video)
        <div class="flex-child">
          <form action="{{route('admin.video.delete',['id'=>$video->id])}}" method="POST">
            <h4 class="text-bold box-title">{{$video->title}}</h4>
            <p>
                <video width="" controls controlsList="nodownload">
                    <source src="{{URL::asset($video->url)}}" type="video/mp4">    
                </video>
            </p>
            @csrf
            @method('delete')
            <p><strong> Course: </strong><span>{{$video->course->title}}</span></p>
            <a class="btn btn-secondary" href="{{route('admin.video.edit',['id'=>$video->id])}}">Edit</a>
            <input class="btn btn-danger" type="submit" value="Delete">
          </form>
        </div>
      @endforeach
    </div>
</div> 
<script>
    function search() {
        var input, filter, flex_container, flex_child, a, i, title, course;
        input = document.getElementById("search-bar");
        filter = input.value.toUpperCase();
        flex_container = document.getElementsByClassName("flex-container");
        flex_child = document.getElementsByClassName("flex-child");
        for (i = 0; i < flex_child.length; i++) {
            h4 = flex_child[i].getElementsByTagName("h4")[0];
            span = flex_child[i].getElementsByTagName("span")[0];
            title = h4.textContent || h4.innerText;
            course = span.textContent || span.innerText;
            if (title.toUpperCase().indexOf(filter) > -1 || course.toUpperCase().indexOf(filter) > -1 ) {
                flex_child[i].style.display = "";
            } else {
                flex_child[i].style.display = "none";
            }
        }
    }
</script>

@endsection


