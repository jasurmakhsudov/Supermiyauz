
@extends('layouts.master')

@section('content')
<link href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" rel="stylesheet">

<div class="container">
    <h1>Edit Video</h1>
    <form action="{{route('admin.video.update')}}" enctype="multipart/form-data" class="form-group" method="POST">
        
        <div class="form-group row">
            <label for="id" class="col-sm-2 col-form-label">Id</label>
            <div class="col-sm-10">
              <input type="text" class="form-control-plaintext" name="id" id="id" value="{{$video->id}}" readonly>
            </div>
        </div>

        <div class="form-group row">
            <label for="title" class="col-sm-2 col-form-label">Title</label>
            <div class="col-sm-10">
              <input type="text" class="form-control" name="title" id="title" value="{{$video->title}}">
            </div>
        </div>
        @csrf
        
        <div class="form-group row">
            <label for="course" class="col-sm-2 col-form-label">Course</label>
            <div class="col-sm-10">
                <select id="course_id" name="course_id" class="form-control" required>
                  <option disabled selected value>-</option>
                    @foreach ($courses as $course)
                        <option value="{{$course->id}}" {{!strcmp($video->course_id,$course->id)?"selected":""}}>{{$course->title}}</option>
                    @endforeach
                </select>
            </div>
        </div>
        <p class="text-center">
            <video width="600" controls controlsList="nodownload">
                <source src="{{URL::asset($video->url)}}" type="video/mp4">    
            </video>
        </p>
        <div class="form-group row">
            <label for="video" class="col-sm-2 col-form-label">Video</label>
            <div class="col-sm-10">
              <input type="file" accept="video/*" class="form-control-file" name="video" id="video">
            </div>
        </div>
        <input class="btn btn-primary" type="submit" value="Update">
        <a class="btn btn-danger" href="{{route('admin.video.index')}}">Cancel</a>
    </form>
</div> 

@endsection


