<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class SmsController extends Controller
{
    public function index()
    {
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, 'notify.eskiz.uz/api/auth/login');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        $post = array(
            'email' => "xayotwork@gmail.com",
            'password' => "6XV9MJBbZmSBYM31SQoV9DYIGqFN3d87vXGRd9NS"
        );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        
        // curl_setopt($ch, CURLOPT_URL, 'http://notify.eskiz.uz/api/auth/user');
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');


        // $headers = array();
        // $headers[] = "Authorization: Bearer ".json_decode($result)->data->token;
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        // $result = curl_exec($ch);
        // if (curl_errno($ch)) {
        //     echo 'Error:' . curl_error($ch);
        // }
        // dd($result);
        // curl_setopt($ch, CURLOPT_URL, 'notify.eskiz.uz/api/message/sms/send');
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // $post = array(
        //     'mobile_phone' => $phone,
        //     'message' => $message,
        //     'from' => "4546",
        //     'callback_url' => "http://0000.uz/test.php"
        // );  
        // // curl_setopt($ch, CURLOPT_POSTFIELDS, $post);

        // $headers = array();
        // $headers[] = "Authorization: Bearer ".json_decode($result)->data->token;
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        // $result = curl_exec($ch);
        // if (curl_errno($ch)) {
        //     echo 'Error:' . curl_error($ch);
        // }
        // curl_close($ch);

        // curl_setopt($ch, CURLOPT_URL, 'https://notify.eskiz.uz/api/user/totals');
        // curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // curl_setopt($ch, CURLOPT_POST, 1);
        // curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
        //     'year' => '2021',
        //     'user_id' => '586',
        // ]));

        // $headers = array();
        // $headers[] = "Authorization: Bearer ".json_decode($result)->data->token;
        // curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        curl_setopt($ch, CURLOPT_URL, 'notify.eskiz.uz/api/message/sms/get-user-messages');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        
        $post = array(
            'start_date' => "2018-12-01 12:00",
            'end_date' => date("Y-m-d H:i:s"),
            'user_id' => "586"
        );
        
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        
        $headers = array();
        $headers[] = "Authorization: Bearer ".json_decode($result)->data->token;
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

        $result = curl_exec($ch);
        if (curl_errno($ch)) {
            echo 'Error:' . curl_error($ch);
        }
        curl_close($ch);

        // return redirect()->route('admin.sms.index',['messages'=>json_decode($result)]);
        return view('admin.sms.index',['messages'=>json_decode($result)->data->data]);
    }
}
