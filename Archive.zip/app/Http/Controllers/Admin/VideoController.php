<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Videos;
use App\Models\Courses;
use Illuminate\Support\Facades\File;

class VideoController extends Controller
{
    public function index()
    {
        return view('admin.video.index',['videos'=>Videos::all()]);
    }

    public function create()
    {
        return view('admin.video.create',['courses'=>Courses::all()]);
    }
    public function store(Request $request)
    {
         // $this->validate($request, [
        //     'name' => 'required',
        //     'phone' => ['required', 'string', 'regex:/^\d{9}$/'],
        // ]);
    
        $video_path="";
        if($request->video)
        {   
            $filename = Courses::find($request->course)->title."_".$request->title.".".$request->video->getClientOriginalExtension();
            // $filename = time().'.'.$request->video->getClientOriginalExtension();
            $request->video->move(public_path('video/course'), $filename);
            $video_path = "video/course/".$filename;
        }
        Videos::create([
            'title' => $request->title,
            'url'=> $video_path,
            'course_id'=> $request->course
        ]);

        return redirect()->route('admin.video.index')->with(['success'=>"Successfully created"]);
    }

    public function delete(Request $request){
        $video=Videos::find($request->id);
        if(file_exists($video->url)){
            unlink($video->url);
        }
        return $video->delete()?redirect()->route('admin.video.index')->with(['success'=>"Successfully deleted"]):route('admin.course.index',['errors'=>"Failed to delete"]);
    } 

    public function edit(Request $request){
        return view('admin.video.edit',['video'=>Videos::find($request->id),'courses'=>Courses::all()]);
    }
    public function update(Request $request){
        $video = Videos::find($request->id);
        
        $video->title = $request->title;
        $video->course_id = $request->course_id;
        
        $video_path="";
        if($request->video)
        {   
            $filename = Courses::find($request->course_id)->title."_".$request->title.".".$request->video->getClientOriginalExtension();
            // $filename = time().'.'.$request->video->getClientOriginalExtension();
            $request->video->move(public_path('video/course'), $filename);
            $video_path = "video/course/".$filename;
            $video->url = $video_path;
        }
        $video->save();
        return redirect()->route('admin.video.index')->with(['success'=>"Successfully edited"]);
    }
}
