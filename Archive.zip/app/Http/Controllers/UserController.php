<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Courses;
use App\Models\Roles;
use Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class UserController extends Controller
{
    public function dashboard(){
        return view('user.dashboard',['courses'=>Courses::all()]);
    }
    
    public function course(){
        return view('user.course',['courses'=>Courses::all()]);
    }

    public function edit(){
        return view('user.edit',['user'=>Auth::user(),'roles'=>User::rolesList()]);
    }

    public function update(Request $request){
        
        $user = User::find($request->id);
        if(($request->password && $request->password)&& !strcmp($request->password, $request->password) ){
                $user->password = Hash::make($request->password);
        }
        $user->save();
        return redirect()->route('user.edit')->with(['success'=>"Successfully edited"]);
    }

    public function showCourse(Request $request){
        
        
        //logic check
        return view('admin.course.show',['course'=>Courses::find($request->id)]);
    }
}
