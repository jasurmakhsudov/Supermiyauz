<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Leeds;

class LeedController extends Controller
{
    public function index()
    {
        return view('admin.leed.index',['leeds'=>Leeds::all()]); 
    }

    public function create(Request $request){
        
        $id = Leeds::create([
            'name' => $request->name,
            'phone'=>$request->phone,
            'course'=>$request->course
        ]);
        return redirect()->route('checkout',
            [
             'name' => $request->name,
             'phone'=>$request->phone,
             'course'=>$request->course,
             'leed_id'=>$id->leed_id
             ]
        );
    }

    public function delete(Request $request){
        return Leeds::find($request->id)->delete()?redirect()->route('admin.leed.index')->with(['success'=>"Successfully deleted"]):route('admin.leed.index',['errors'=>"Failed to delete"]);
    }
    
}
