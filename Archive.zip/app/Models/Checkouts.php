<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Checkouts extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'phone',
        'referral',
        'leed_id',
        'course_id',
        'amount'
    ];

    protected $primaryKey = 'checkout_id';
    
    public function leeds(){
        return $this->hasOne(Leeds::class, 'leed_id', 'id');
    }
    
}
