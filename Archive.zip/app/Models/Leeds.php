<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Leeds extends Model
{
    use HasFactory;

    protected $fillable = [
        'name',
        'phone',
        'course'
    ];
    
    public function checkout()
    {
        return $this->belongsTo(Checkouts::class);
    }
}
