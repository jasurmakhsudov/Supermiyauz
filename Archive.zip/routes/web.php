<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CheckoutsController;
use App\Http\Controllers\LeedController;
use App\Http\Controllers\CustomAuthController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [HomeController::class,'index'])->name('index');

Route::post('/leeds', [LeedController::class,'create'])->name('leedCreate');

Route::get('/checkout/{course?}', [CheckoutsController::class,'index'])->name('checkout');

Route::get('/checkout/{course}/{name}/{phone}/{amount?}', [CheckoutsController::class,'invoice'])->name('invoice');

Route::post('/checkout', [CheckoutsController::class,'create'])->name('checkout');

Route::post('/checkout/login', [CheckoutsController::class,'login'])->name('login');

Route::get('/login', [HomeController::class,'login'])->name('login');

Route::get('/thankyou/{course_id?}/{name?}', [HomeController::class,'thankyou'])->name('thankyou');

//Auth::routes(['register' => false]);

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::group(['as' => 'admin.', 'prefix' => 'admin','namespace' => 'Admin', 'middleware' => ['auth', 'can:admin']], function () {
    
    Route::get('/dashboard', [App\Http\Controllers\Admin\DashboardController::class, 'dashboard'])->name('dashboard');
    
    Route::group(['as' => 'user.', 'prefix' => 'user',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
        Route::get('/', [App\Http\Controllers\Admin\UserController::class, 'show'])->name('index');
        Route::get('/create', [App\Http\Controllers\Admin\UserController::class, 'create'])->name('create');
        Route::post('/store', [App\Http\Controllers\Admin\UserController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [App\Http\Controllers\Admin\UserController::class, 'edit'])->name('edit');
        Route::post('/edit', [App\Http\Controllers\Admin\UserController::class, 'update'])->name('update');
        Route::delete('/delete/{id}', [App\Http\Controllers\Admin\UserController::class, 'delete'])->name('delete');
    });
    
    Route::group(['as' => 'course.', 'prefix' => 'course',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
        Route::get('/', [App\Http\Controllers\Admin\CoursesController::class, 'index'])->name('index');
        Route::get('/create', [App\Http\Controllers\Admin\CoursesController::class, 'create'])->name('create');
        Route::post('/store', [App\Http\Controllers\Admin\CoursesController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [App\Http\Controllers\Admin\CoursesController::class, 'edit'])->name('edit');
        Route::post('/edit', [App\Http\Controllers\Admin\CoursesController::class, 'update'])->name('update');
        Route::delete('/delete/{id}', [App\Http\Controllers\Admin\CoursesController::class, 'delete'])->name('delete');
    });

    Route::group(['as' => 'video.', 'prefix' => 'video',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
        Route::get('/', [App\Http\Controllers\Admin\VideoController::class, 'index'])->name('index');
        Route::get('/create', [App\Http\Controllers\Admin\VideoController::class, 'create'])->name('create');
        Route::post('/store', [App\Http\Controllers\Admin\VideoController::class, 'store'])->name('store');
        Route::get('/edit/{id}', [App\Http\Controllers\Admin\VideoController::class, 'edit'])->name('edit');
        Route::post('/edit', [App\Http\Controllers\Admin\VideoController::class, 'update'])->name('update');
        Route::delete('/delete/{id}', [App\Http\Controllers\Admin\VideoController::class, 'delete'])->name('delete');
    });

    Route::group(['as' => 'sms.', 'prefix' => 'sms',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
        Route::get('/', [App\Http\Controllers\Admin\SmsController::class, 'index'])->name('index');
        Route::get('/create', [App\Http\Controllers\Admin\VideoController::class, 'create'])->name('create');
        // Route::post('/store', [App\Http\Controllers\Admin\VideoController::class, 'store'])->name('store');
        // Route::get('/edit/{id}', [App\Http\Controllers\Admin\VideoController::class, 'edit'])->name('edit');
        // Route::post('/edit', [App\Http\Controllers\Admin\VideoController::class, 'update'])->name('update');
        // Route::delete('/delete/{id}', [App\Http\Controllers\Admin\VideoController::class, 'delete'])->name('delete');
    });

    Route::group(['as' => 'leed.', 'prefix' => 'leed',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
        Route::get('/', [App\Http\Controllers\LeedController::class, 'index'])->name('index');
        Route::delete('/delete/{id}', [App\Http\Controllers\LeedController::class, 'delete'])->name('delete');
        // Route::get('/create', [App\Http\Controllers\Admin\VideoController::class, 'create'])->name('create');
        // Route::post('/store', [App\Http\Controllers\Admin\VideoController::class, 'store'])->name('store');
        // Route::get('/edit/{id}', [App\Http\Controllers\Admin\VideoController::class, 'edit'])->name('edit');
        // Route::post('/edit', [App\Http\Controllers\Admin\VideoController::class, 'update'])->name('update');
        // Route::delete('/delete/{id}', [App\Http\Controllers\Admin\VideoController::class, 'delete'])->name('delete');
    });
});

Route::group(['as' => 'user.', 'prefix' => 'user','namespace' => 'User', 'middleware' => ['auth']], function () {
    Route::get('/dashboard', [App\Http\Controllers\UserController::class, 'dashboard'])->name('dashboard');
    Route::get('/edit', [App\Http\Controllers\UserController::class, 'edit'])->name('edit');
    Route::post('/edit', [App\Http\Controllers\UserController::class, 'update'])->name('update');
    Route::get('/course/{id}', [App\Http\Controllers\UserController::class, 'showCourse'])->name('showCourse');
    Route::get('/course', [App\Http\Controllers\UserController::class, 'course'])->name('course');
    // Route::get('/users', [App\Http\Controllers\Admin\UserController::class, 'show'])->name('showUsers');
    // Route::get('/user/create', [App\Http\Controllers\Admin\UserController::class, 'create'])->name('createUser');
    // Route::post('/user/store', [App\Http\Controllers\Admin\UserController::class, 'store'])->name('storeUser');
    // Route::get('/user/edit/{id}', [App\Http\Controllers\Admin\UserController::class, 'edit'])->name('editUser');
    // Route::post('/user/edit', [App\Http\Controllers\Admin\UserController::class, 'update'])->name('updateUser');
    // Route::delete('/user/delete/{id}', [App\Http\Controllers\Admin\UserController::class, 'delete'])->name('deleteUser');

    
    // Route::group(['as' => 'course.', 'prefix' => 'course',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
    //     Route::get('/', [App\Http\Controllers\Admin\CoursesController::class, 'index'])->name('index');
    //     Route::get('/create', [App\Http\Controllers\Admin\CoursesController::class, 'create'])->name('create');
    //     Route::post('/store', [App\Http\Controllers\Admin\CoursesController::class, 'store'])->name('store');
    //     Route::get('/edit/{id}', [App\Http\Controllers\Admin\CoursesController::class, 'edit'])->name('edit');
    //     Route::post('/edit', [App\Http\Controllers\Admin\CoursesController::class, 'update'])->name('update');
    //     Route::delete('/delete/{id}', [App\Http\Controllers\Admin\CoursesController::class, 'delete'])->name('delete');
    // });

    // Route::group(['as' => 'video.', 'prefix' => 'video',/*'namespace' => 'Admin', 'middleware' => ['auth', 'can:admin-panel'] */], function () {
    //     Route::get('/', [App\Http\Controllers\Admin\VideoController::class, 'index'])->name('index');
    //     Route::get('/create', [App\Http\Controllers\Admin\VideoController::class, 'create'])->name('create');
    //     Route::post('/store', [App\Http\Controllers\Admin\VideoController::class, 'store'])->name('store');
    //     Route::get('/edit/{id}', [App\Http\Controllers\Admin\VideoController::class, 'edit'])->name('edit');
    //     Route::post('/edit', [App\Http\Controllers\Admin\VideoController::class, 'update'])->name('update');
    //     Route::delete('/delete/{id}', [App\Http\Controllers\Admin\VideoController::class, 'delete'])->name('delete');
    // });
});


//auth
Route::get('dashboard', [CustomAuthController::class, 'dashboard']); 
Route::get('login', [CustomAuthController::class, 'index'])->name('login');
Route::post('custom-login', [CustomAuthController::class, 'customLogin'])->name('login.custom'); 
Route::get('registration', [CustomAuthController::class, 'registration'])->name('register-user');
Route::post('custom-registration', [CustomAuthController::class, 'customRegistration'])->name('register.custom'); 
Route::get('signout', [CustomAuthController::class, 'signOut'])->name('signout');